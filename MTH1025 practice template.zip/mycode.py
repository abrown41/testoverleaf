"""
When you're happy with the code you have written, simply copy and paste it out of the jupyter notebook and in here. Remember that I don't want to see all your plotting commands etc. Just the bit of your code which actually solves the equations.
"""

x=np.linspace(0,2*np.pi,1000)
y=np.sin(x)
plt.plot(x,y)