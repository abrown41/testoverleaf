def plot_script():
    # code to plot the sine function
    import numpy as np
    x=np.linspace(0,2*np.pi,1000)
    y=np.sin(x)
    plt.plot(x,y)